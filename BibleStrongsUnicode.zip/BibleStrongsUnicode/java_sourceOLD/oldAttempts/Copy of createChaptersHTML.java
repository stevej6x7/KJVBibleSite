x import java.io.*;

import java.text.DecimalFormat;
import java.util.*;

/**
*   createChaptersHTML - <BR>
*     Open a unicode utf-16 bigEndian file containing one book of the Bible.
*     This is intended to read lines that look like this:<br>
*     18  I have waited for <06960> (8765) thy salvation <03444>, O LORD <03068>. 81  ???????? ????? ????<br>
*     The question marks are Hebrew(or Greek) unicode characters.<br>
*     I haven't been able to find a unicode editor.<br>
*     Read each line,
*     Add HTML tags to reformat the text into HTML.
*     Write each chapter into a separate "chapter file".
*
**/
class createChaptersHTML {
	
    // Use this to combine with other characters to identify Bible text in English
    private static String someText = "[A-Za-z;,'.?:! \"]+";

	static public void main (String[] args) {
		
       InputStreamReader rdr = null;
       BufferedWriter out = null;
       
       // try {
          
          // get the list of files; input, output pair of directory paths.          
          Vector booklistOT = new Vector();                   
          // booklistOT.add("C:\\BibleStrongsUnicode\\KJVOldTestamentAndHebrew");
          booklistOT.add("C:\\BibleStrongsUnicode\\oneBookOT");
          booklistOT.add("C:\\BibleStrongsUnicode\\KJVOldTestamentAndHebrewHTML");
          
          // get the list of files; input, output pair of directory paths.          
          Vector booklistNT = new Vector();                   
          // booklistNT.add("C:\\BibleStrongsUnicode\\KJVNewTestamentAndGreekWH");
          booklistNT.add("C:\\BibleStrongsUnicode\\oneBookNT");
          booklistNT.add("C:\\BibleStrongsUnicode\\KJVNewTestamentAndGreekWHHTML");
          
          Vector allTheDirectoryPaths = new Vector();
          allTheDirectoryPaths.add(booklistOT);
          allTheDirectoryPaths.add(booklistNT);
          
          int firstByte = 0;
          StringBuffer theFile = new StringBuffer();

          // Use each directory name to return a list of book names from that directory.
          // This is a list of directories containing books of the Bible, usually one
          // for Old and one for New Testament.
          Enumeration enum = allTheDirectoryPaths.elements();
          while (enum.hasMoreElements()){
             // This allows us to loop over the directories of OT and NT books.
             // In theory there could be several versions of the Bible, we use KJV.
          	 Vector inputOutputDirectoryStrings = (Vector)enum.nextElement();
             String inputDirectoryString = (String)inputOutputDirectoryStrings.firstElement();
             String outputDirectoryString = (String)inputOutputDirectoryStrings.lastElement();
          
             File directoryOfInputFiles = new File(inputDirectoryString);
          
             String [] bookFileNames = directoryOfInputFiles.list();
       
       // Loop to read each txt file and generate an HTML file
       // 
             for (int i=0; i < bookFileNames.length; i++ ) {
                try{
                // open file for reading, unicode bigendian.
                      // new BufferedReader(
                FileInputStream FIStream = new FileInputStream(inputDirectoryString + "\\"+ bookFileNames[i]);               
                
       rdr = 
                          new InputStreamReader(FIStream, "UTF-16");
                          // new InputStreamReader(FIStream, "UTF-16BE");
                
                // read the header of txt bigEndian files.
                // firstByte = FIStream.read();

      }catch (Exception e) {
      	System.out.println(e.toString());
                 e.printStackTrace(System.out);
      	         System.exit(0);
               } // catch

      String line = "";
               int lineCount = 0;
               long chapterCount = 0;
               int charCount = 0;
      
      try { 
                  // Read each line and write it after formatting HTML
                  while (true) {
                  	   charCount++;
                  	   
                  	  // Not sure if reading one char is reading a byte or a full char.
                  	  char[] aChar = new char[1];
                  	  int charFound = rdr.read(aChar, 0, 1);
                                  
                                  if (charFound == -1) {
                                      // end of file
                                      break;
                                  }

                         if ( (charCount % 20) == 0) {
                         	System.out.println("\n");
                         }
                         System.out.print(Integer.toHexString((int)aChar[0]) + "  " + aChar[0]);

                  	  theFile.append(aChar[0]);
                  }
                
                  String[] lines = (theFile.toString()).split("\n");

                  for (int j=0; j < lines.length; j++) {
                  	
                  	  line = lines[j];
                  	  lineCount++;
                  	  
                  	  System.out.println("inputLine: " + line);
                  	  
                  	  byte[] bRay = line.getBytes();
                  	  String utfString  = new String(bRay, "UTF-16");
                  	  byte[] bbRay = utfString.getBytes();
                  	  for (int k =0; k<bbRay.length; k++){
                         if ( (k % 20) == 0) {
                         	System.out.println("\n");
                         }
                         System.out.print(Integer.toHexString(bbRay[k]) + "  ");
                      }


                  	  byte[] utfbRay = line.getBytes("UTF-16");
                  	  String utfbRayString  = new String(utfbRay);
                  	  for (int k =0; k<utfbRay.length; k++){
                         if ((k % 20) == 0 ) {
                         	System.out.println("\n");
                         }
                         System.out.print(Integer.toHexString(utfbRay[i]) + "  ");
                      }

                  	  // If this is a new chapter then open a new html file for
                  	  // writing each chapter. The files we are reading do not contain
                  	  // chapter numbers, but simply contain the verse numbers so
                  	  // we determine each chapter start by looking for the first verse.
                  	  if (line.indexOf("1 ") == 0 || lineCount == 1) {
                      
                        System.out.println("new chapter: " + lineCount);                     
                        // close if open for next chapter output file.
                        if (out != null ) {
                        	out.flush();
                        	out.close();
                        	out = null;                        
                        }
      
                        // Format each chapter number to have leading zeros. This is 
                        // so that the chapters will be numerically listed, even though
                        // they are alphabetically sorted.
                        chapterCount++;
                        DecimalFormat leadingZeros = new DecimalFormat("000");
                        String zeroPaddedCount = leadingZeros.format(chapterCount);
                        
                        // File names input are expected to be txt files, drop the .txt here.
                        int periodIndex = bookFileNames[i].indexOf(".txt");
                        String bookFileNameMinustxt = bookFileNames[i].substring(0,periodIndex);
                        System.out.println("output chapter: " + bookFileNameMinustxt);
                        
                        // create an output file with the name formatted like this:
                        // Genesis001.html
                        try {
                           FileOutputStream FOS = new FileOutputStream(outputDirectoryString + "\\"+ 
                                                    bookFileNameMinustxt + zeroPaddedCount + ".html");
                          
                           FOS.write(firstByte);

                out = 
                     new BufferedWriter(
                                     new OutputStreamWriter( FOS));
                           
               }catch (Exception e) {
      	         System.out.println(e.toString());
       	                    e.printStackTrace(System.out);
       	                    System.exit(0);
                         } //catch
                      } // if
                  
               //################################################
               // THIS IS ADDING THE HTML THAT MAKES THE TEXT EASILY READABLE
               // YOU MAY WANT TO EXTEND THIS IN SUBCLASSES OR MAKE IT CONFIGURABLE
               // WITH A GUI
               //################################################
                      // COMMENTED OUT TEMPORARILY line = addHTML(line);

                      if (out != null) {
                      out.write(line);
                      }
                  } // while
               // Close the file
               rdr.close();
    
                                  // close if open for next chapter output file.
                        if (out != null ) {
                        	out.flush();
                        	out.close();                        
                    out = null;                        
                        }
          } catch (Exception e ){
  	         System.out.println(e.toString());
             e.printStackTrace(System.out);
      	     System.exit(0);
          } //catch   

          } // for each book in a directory

       } // while more directories
   }

   static public String addHTML( String line) {   
   	     System.out.println("Entering addHTML: " + line);
   	        
         // does line start with 1? If so bump counter and open new chapter for this book.
         //                                          add opening headers, and table start


         // Example line:
         //  18  I have waited for <06960> (8765) thy salvation <03444>, O LORD <03068>. 81  ???????? ????? ????<br>

         // replace all < > with [ ]. The < > are HTML tags, so we will use a different 
         // Strong's number deliniator. 
         line = line.replaceAll("<","[");
         line = line.replaceAll(">","]");
         
         // Begin each line with opening tags.
         // Find this: 18  I have waited for 
         line = line.replaceFirst("^(\\d+" + someText + ")", "OPENING LINE TABLE $0 OPENING TABLE");
         
         // Separate the words from the [##], (##) Strongs numbers that identify the words.
         // Notice that some of these replacements will find overlapping chunks of text
         //   to insert HTML before and after text.
         // Find this: I have waited for [
         line = line.replaceAll("(" + someText + ")\\[", "$1 OPEN UNDER [");
         line = line.replaceAll("(" + someText + ")\\(", "$1 OPEN UNDER (");
         
         // Group these [##] and (##) together somehow, currently we will put these numbers under the words
         // they identify in an HTML table.
         // Find this: ] (
         //    or any combination of these.
         line = line.replaceAll("\\] \\(", "] STAY UNDER (");
         line = line.replaceAll("\\] \\[", "] STAY UNDER [");
         line = line.replaceAll("\\) \\(", ") STAY UNDER (");
         line = line.replaceAll("\\) \\[", ") STAY UNDER [");
         
         // Create an HTML table such that the words are on the same line with the numbers below. 
         // Find this: ) thy salvation 
         line = line.replaceAll("\\](" + someText + ")", "] CLOSE UNDER, NEXT WORD $1");
         line = line.replaceAll("\\)(" + someText + ")", ") CLOSE UNDER, NEXT WORD $1");
         
         // Put Hebrew/Greek on next line(row).
         // Find this if it exists: ] 81
         line = line.replaceAll("\\]( ?\\d+)", "] CLOSE ROW, NEXT ROW $1");
         line = line.replaceAll("\\)( ?\\d+)", ") CLOSE ROW, NEXT ROW $1");
         
         // Put Hebrew/Greek on next line(row).
         // Find this: . 81
         line = line.replaceAll("(" + someText + ")( ?\\d+)", "$1 CLOSE ROW, NEXT ROW $2");
         
         // Close each line with closing HTML
         line = line.replaceAll("$", "CLOSE LINE TABLE");
         line = line + "\n";

         return line;  
  }
}

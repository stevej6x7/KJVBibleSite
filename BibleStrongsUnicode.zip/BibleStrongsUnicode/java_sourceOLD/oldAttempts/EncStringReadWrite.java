import java.io.*;

public class EncStringReadWrite
{
   public static void main(String[] args)
   {
      try {
         FileInputStream aFile = new FileInputStream("C:\\BibleStrongsUnicode\\oneBookOT\\aGenesis.txt");
         InputStreamReader rdr = new InputStreamReader(aFile, "utf-16be");


        OutputStream outFile= new FileOutputStream("encstringWrite.txt");
        OutputStreamWriter outUtf
                          = new OutputStreamWriter(outFile, "utf-16be");


		 BufferedReader in = new BufferedReader(rdr);

		 String str = "";

		 while (true) {

		     str = in.readLine();
		     if (str == null) break;
		     System.out.println("ourString:" + str);
		     str = str.replaceAll("a", "A");
		     System.out.println("ourString with b:" + str);
		     str += "\r\n";

		     outUtf.write(str , 0, str.length());


		 }

		 aFile.close();
		 rdr.close();
		 outFile.flush();
		 outUtf.flush();
		 outFile.close();
		 outUtf.close();


     } catch(Exception e){
		 System.out.println("ERROR:" + e.toString());
	 }

   }
}  // End class

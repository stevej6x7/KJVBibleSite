Hi Steve,

The results are in:
BibleStrongsUnicode  - This has a readme and some PDF files that are helpful.
BibleStrongs       - ASCII copy of things
HexViewer          - File viewer to see what the actual bits in a file are, including the MS header.
PerlFiles   -     The main file here is doit.bat, most of the other files are experiments, except for what doit.bat uses.
BIBLE - Contents of the original CD
WinMerge is a free merge progam that makes a nice little script editor also. I make a backup of a file
                 and then change on line in the backup. Then open the file and the backup in winmerg, making
                 edits to the script file I'm working on. You may have a nicer editor already.
Perl install - you may have one already, this is what I used.
 
great-engineers@google.com

Steve
How to get this kind of text.

THIS IS GOD's WORD, BE CAREFUL!!!!!!!

Open the Online Bible.
1.
Select the version of the Bible that you want to get the ascii text from.
It may be English, Greek, or Hebrew. 
For English KJV, turn on Strongs Numbers, by clicking the button on the Online Bible.
The Online Bible documentation gives
the mapping from the English keyboard to what each of the characters in
Greek or Hebrew is. The final forms in Hebrew are obtained programmatically
by checking to see if the next character in the text is white space( blank,
end of sentence, end of line) or a hyphen (-). Then the appropriate font is
applied in the program for display. The point is that the final forms are
not contained in this ascii text, but are derived from where they belong in
the context of the letters.

2.
Select "view passage".

3.
Enter "gen". in the search field for Genesis 1:1

4.
Now scroll down using the down arrow on the keyboard.
Notice that the chapters will scroll by( you can see the chapters in the frame
containing the text). You can stop scrolling when
you get to chapter 50. (It helps to know the last chapter of each book, or
you will need to carefully highlight or remove some of the next books text
from each of the current book you are getting ascii text for)

5. 
Now you have the current book loaded into memory, you are ready to copy.

6.
Scroll back to the beginning of the Book, using the mouse and scroll bar.
Do not attempt to highlight the text in reverse for copying or it will 
unhighlight each time you push the <ctrl> key.

7.
Now, with the cursor at the beginning of the first line, use the mouse to put the
cursor before the 1 on the first verse of the chapter. Then use the mouse to highlight all of the text in the Book.

8.
Let go of mouse button when the end of the book is reached.

9.
Push and hold <ctrl>, then push and hold<Shift>, then push<c>
holding down all three keys. Then let go, you have copied the Book to the copy
buffer.

10. 
Open your favorite text editor, on windows I use vim.exe or notepad.exe

11.
You can 'paste' the text by using the tool bar "Edit->paste" or <ctrl><v>
Notice that Hebrew and Greek are displayed using English letters.
If you get the Greek and Hebrew fonts imported into your windows environment
then you can paste into Word and the fonts will be retained, which will display
the final forms in Hebrew. (Search for "font" in file names in the Online Bible
install CD to understand how fonts are handled, there is pretty good info)
The chapter numbers are not included. You can carefully add them if you want.
Be very careful not to change or delete any text.

12. I suggest one file per Book of the Bible, with English text in the top level
directory, and separate directories for each version of Greek and Hebrew in the
top level directory. You can organize according to your needs. You might use
a file naming convention that would allow all the files for all the books in
one directory.

13.
Why did I spend all day doing this?
Now you can search on the text with any tool you want. You can use Regular Expressions.
You can write a Perl program, use Vi, use Windows tools, whatever you want. This gives you freedom to search without the restriction of a program telling how to
search and what is searchable. You can do a diff(UNIX command) on various versions of
Greek and Hebrew text. Lots of fun stuff. You decide.

14.
copy this to a backup CD or removable media for safe keeping.
It is probably a good idea to make all of the files "Read Only" to protect the text.
THIS IS GOD's WORD, BE CAREFUL!!!!!!!


a Alpha     a  
 b Beta      b   
 g Gamma     g   
 d Delta     d  
 e Epsilon   e  
 z Zeta      z   
 h Eta       h   
 q Theta    y    
 i Iota      i   
k Kappa     k   
l Lambda    l   
m Mu        m   
 n Nu        n 
x Xi        x   
o Omicron   o   
p Pi        p  
r Rho         r
s, V Sigma   s,v 
t Tau         t
u Upsilon     u
f Phi         f 
c Chi         c
y Psi         q
w Omega       w 


 a Aleph        a 
 b Beth         b  
 g Gimel        g  
 d Daleth       d 
 h He           h 
 w Waw          w  
 z Zayin        z  
 x Cheth        x  
 j Tet          j   
y Yod          y   
k, K Kaph     k,K  
l Lamedh       l   
m, M Mem      m,M  
n, N Nun      n,N  
o Samekh       o   
e Ayin         e
p, P Peh      p,P
u, U Tsadhe   u,U
q Qoph         q
r Resh         r
v Sin          v
s Shin         s
t Tau          t

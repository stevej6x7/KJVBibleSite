Hi Steve Osborne,

The interesting stuff is in:
C:\BibleStrongsUnicode\java_source\doitJava.bat
C:\BibleStrongsUnicode\KJVOldTestamentAndHebrewHTML
C:\BibleStrongsUnicode\KJVNewTestamentAndGreekWHHTML

I havent tried the links to bju.edu/bible/strongs/Hebrew/123.inc,
but they might work.

2Chron. is complete, but needs an index page.

Thanks,
Steve Johnson

x import java.io.*;

import java.text.DecimalFormat;
import java.util.*;

/**
*   createChaptersHTML - <BR>
*     Open a unicode utf-16 bigEndian file containing one book of the Bible.
*     This is intended to read lines that look like this:<br>
*     18  I have waited for <06960> (8765) thy salvation <03444>, O LORD <03068>. 81  ???????? ????? ????<br>
*     The question marks are Hebrew(or Greek) unicode characters.<br>
*     I haven't been able to find a unicode editor.<br>
*     Read each line,
*     Add HTML tags to reformat the text into HTML.
*     Write each chapter into a separate "chapter file".
*
**/
class createChaptersHTML {
 
    private OutputUTF16File OStream = new OutputUTF16File();
    private int longLineLength = 0;
    private String longName = "";
       
       // Because we are opening each book as a file, but writing each chapter as a file, we
       // need the header character identifying the encoding as the first character of each
       // line that is the first line of a chapter.
    private char header = ' ';
          
    private static String language = "Hebrew";
    private static String HTMLformat = "Full";  // Full, Simple, Original

    // Use this to combine with other characters to identify Bible text in English
    private static String someText = "[A-Za-z;,'.?:! \"()]+";
    private static String HTML_FILE_BEGIN = "<HTML>\n" 
                          + "<TITLE>Bible Study Aide BOOKNAME Chapter CHAPTERNUMBER</TITLE>\n" 
                          + "<STYLE>\n" 
                          + "     TR.small {font: 8pt }\n" 
                          + "     SPAN.red {background: #F2B4AD}\n" 
                          + "     SPAN.blue {background: #A8D6F7}\n" 
                          + "     SPAN.green {background: #D5E3B6}\n" 
                          + "     SPAN.tan {background: tan}\n" 
                          + "     SPAN.hebrew {background: #88FF88; font: 17pt Times}\n" 
                          + "     SPAN.english{font: 12pt Times}\n" 
                          + "     TR.hebrew {background: #88FF88; font: 17pt Times}\n" 
                          + "</STYLE>\n" 
                          + "<H2 align=\"center\">\n" 
                          + "   BOOKNAME Chapter CHAPTERNUMBER\n" 
                          + "</H2>\n" 
                          +"<br>"
                          +"<A href=RELATIVEPATHONE>RELATIVEPATHONEFORMAT</A>"
                          +"<A href=RELATIVEPATHTWO>RELATIVEPATHTWOFORMAT</A>"
//                          +"<A href=../KJVNewTestamentAndGreekWHHTML/aMatthew001.html>full</A>"
//                          +"<A href=../KJVNewTestamentAndGreekWHSimpleHTML/aMatthew001.html>simple</A>"
                          + "<BODY>\n";
    
    private static String HTML_FILE_END = "</BODY>"
                                        + "</HTML>";

   createChaptersHTML(){
   	}                                    

   static public void main (String[] args) {
   	
   	createChaptersHTML create = new createChaptersHTML();
    create.createHTMLFiles("Full");
    create.printLongestLine();

   	// Minimal HTML added, KJV with Strongs #s, and Grk/Hebrew at the end of each line.
   	create = new createChaptersHTML();
    create.createHTMLFiles("Simple");
    create.printLongestLine();
		       
    // Original language only.
   	create = new createChaptersHTML();
    create.createHTMLFiles("Original");
    create.printLongestLine();
  }  

   public boolean createHTMLFiles(String HTMLOutputformat){
    
    this.HTMLformat = HTMLOutputformat;
     FileNameParts fileNameParts = null;

     try {
        fileNameParts = new FileNameParts(HTMLOutputformat);
    } catch (Exception e) {
        System.out.println(e.toString());        
    }

      while (fileNameParts.hasMoreElements()){
             
             // This allows us to loop over the directories of OT and NT books.
             // In theory there could be several versions of the Bible, we use KJV.
             Vector inputOutputDirectoryStrings = (Vector)fileNameParts.nextElement();
          
             createOutputDirectoryIfNeeded(fileNameParts.getOutputDirectoryString());
             
             // Need language string to complete linking URLs in some cases, like: bju.edu/bible/strongs/Hebrew/123.inc
             if ( fileNameParts.getInputDirectoryString().indexOf("Hebrew") > 0) language = "Hebrew";
             if ( fileNameParts.getInputDirectoryString().indexOf("Greek") > 0) language = "Greek";

             File directoryOfInputFiles = new File(fileNameParts.getInputDirectoryString());
             System.out.println("Directory of input files: " + fileNameParts.getInputDirectoryString());
          
             String [] bookFileNames = directoryOfInputFiles.list();
             if ( bookFileNames == null ) {
             	System.out.println("Files not found in: " + fileNameParts.getInputDirectoryString());
             	continue;
             }
       
       // Loop to read each txt file and generate an HTML file
             for (int i=0; i < bookFileNames.length; i++ ) {
               fileNameParts.setCurrentFileName( bookFileNames[i] );
                        
                // open file for reading, unicode bigendian.
                    InputUTF16File IStream = new InputUTF16File();    
		       BufferedReader in = IStream.open(fileNameParts.getFullInputFile());

               String line = "";

      try { 
                  boolean firstLine = true;
                  boolean firstChapterLine = true;
                  // Read each line and write it after formatting HTML
                  while (true) {
                  	   
		     line = in.readLine();
		             //System.out.println(line);
		    
                     // Hit the end of the chapter. Go get another input Book.
                     if (line == null){ break;} 
                     
                     // This identifies start of book
                     if (firstLine && line.length() > 0) {
                        firstLine = false;
                        firstChapterLine = true; 
                        fileNameParts.resetChapterCount(); 
                        System.out.println("GOT THE HEADER");
                        header  = line.charAt(0); 
                        line = line.substring(1,line.length());
                         }

                     // This identifies start of each chapter
                     if (line.indexOf("1 ") == 0 ) {                                                 
                        firstChapterLine = true; 
                     }
                     
                     int lineLength = line.length();
                     if (lineLength > longLineLength){
                        longLineLength = lineLength;
                    	longName = fileNameParts.getBookFileNameMinustxt() + fileNameParts.getChapter();
                     } 
                     
                     // If this is a new chapter then open a new html file for
                     // writing each chapter. The files we are reading do not contain
                     // chapter numbers, but simply contain the verse numbers so
                     // we determine each chapter start by looking for the first verse.
                     if (firstChapterLine ) {                                                  
                        closeAndOpenChapterFile( 
                             fileNameParts,
                             OStream);                                                                              

                   } // if                   
                   
               //################################################
               // THIS IS ADDING THE HTML THAT MAKES THE TEXT EASILY READABLE
               // YOU MAY WANT TO EXTEND THIS IN SUBCLASSES OR MAKE IT CONFIGURABLE
               // WITH A GUI
               //################################################
                   
                   if (HTMLformat == "Full") {
                      line = addHTMLFull(line);
                   } else if (HTMLformat == "Simple") {
                      line = addHTMLSimple(line);
                   } else if (HTMLformat == "Original") {
                      line = addHTMLOriginal(line);
                   }  

                      // Add new line info back for some reason.
                      line += "\r\n";

                   if (OStream.isOpen()) {
                      if ( firstChapterLine ) {
                            // new chapter, that is not the first chapter, so put encoding info first.
                         // This needs to happen right before the write, because we do substitutes that might
                         // collide in addHTML()
                            line  = header + HTML_FILE_BEGIN + line;
                         line = line.replaceAll("BOOKNAME", fileNameParts.getPrinterBookName()) ;
                         line = line.replaceAll("CHAPTERNUMBER", "" + fileNameParts.getChapter());
                         
                         line = line.replaceAll("RELATIVEPATHCURRENTFORMAT", fileNameParts.getCurrentHTMLFormat()+"Index");
                         line = line.replaceAll("RELATIVEPATHCURRENT", fileNameParts.getRelativeCurrentIndexFileName());
                         line = line.replaceAll("RELATIVEPATHONEFORMAT", fileNameParts.getRelativePathFormatOne());
                         line = line.replaceAll("RELATIVEPATHONE", fileNameParts.getRelativePathOne());
                         line = line.replaceAll("RELATIVEPATHTWOFORMAT", fileNameParts.getRelativePathFormatTwo());
                         line = line.replaceAll("RELATIVEPATHTWO", fileNameParts.getRelativePathTwo());
                            firstChapterLine = false;
                      }

                      OStream.write(line , 0, line.length());
                         
                      } // if
                  } // while
                  
                  // Close the input file
                  IStream.close();
    
               // We don't know the last chapter number until we are done reading the book.
               fileNameParts.addBookAndLastChapter();
                  
               OStream.write(HTML_FILE_END , 0, HTML_FILE_END.length());                  
                  OStream.closeOut("closing last chapter");
                  
          } catch (Exception e ){
  	         System.out.println(e.toString());
             e.printStackTrace(System.out);
      	     System.exit(0);
          } //catch   

          } // for each book in a directory

       } // while more directories
   	    	
       // create indexes for this format of Bible. It will contain links
       // to the other formats, for the parts that are at their level.
       createIndex(fileNameParts);
   	    	
   	    	return true;
   	    }
    
    public void closeAndOpenChapterFile(
       FileNameParts fileNameParts, 
                            OutputUTF16File OStream        // This gets created once at top and handles streams on open and close.
                            ) throws IOException {
        
                        // close if open for next chapter output file.
                        if (OStream.isOpen() ) {
                  
                           OStream.write(HTML_FILE_END , 0, HTML_FILE_END.length());                           
                           OStream.closeOut("closing chapter, not the last.");
                      
                        } // if
                           
      fileNameParts.incrementChapter();
                       // create an output file with the name formatted like this:
                       // Genesis001.html
      OStream.open(fileNameParts.getFullOutputFile());
        }   	
   
   static public String addHTMLFull( String line) {
   	 //System.out.println("Entering addHTML: " + line);
   	 
   	    final String OPENING_LINE_TABLE = "<TABLE width=3000><TR><TD><TABLE><TR VALIGN=\"top\"><TD>";
           
        final String OPENING_TABLE = "</TD><TD><TABLE><TR><TD><SPAN class=english>";
    // This dollar two is substituting the strongs number in at run time from the matched text. There are two
    // matches in this replace, and the number is the second.    
        final String OPEN_UNDER = "</SPAN></TR><TR CLASS=small><TD><A HREF=http://www.bju.edu/resources/strongs/_LANGUAGE/$2.inc target=strongs>";
    // This dollar one is substituting the strongs number in at run time from the matched text. There is only
    // one match in this replace.
        final String STAY_UNDER = "</A><BR><A HREF=http://www.bju.edu/resources/strongs/_LANGUAGE/$1.inc target=strongs>";
        final String CLOSE_UNDER = "</A></TR></TABLE></TD><TD><TABLE><TR><TD><SPAN class=english>";
        final String NEXT_WORD = "NEXT_WORD";
        final String CLOSE_ROW = "</SPAN></TR><TR CLASS=small><TD></TR></TABLE></TD></TR></TABLE>";
        final String NEXT_ROW = "</TD></TR><TR class=hebrew><TD><TABLE width=900><TR><TD align=\"right\"><SPAN class=hebrew>";
        final String CLOSE_LINE_TABLE = "</SPAN> </SPAN><p></TR></TABLE></TR></TABLE>";

   	        
         // does line start with 1? If so bump counter and open new chapter for this book.
         //                                          add opening headers, and table start


         // Example line:
         //  18  I have waited for <06960> (8765) thy salvation <03444>, O LORD <03068>. 81  ???????? ????? ????<br>

         //////////// REMOVING OR REPLACING SECTION. CLEAN UP CHARACTERS FOR HTML TAGS. ////////// 
         // clean up extra <00>
         line = line.replaceAll("<0+>","");
         // remove leading 0s in strongs for now, bju.edu/bible doesnt use them.  
         line = line.replaceAll("<0(\\d+)>","<$1>");
         
         // change >3:2< to =3:2=
         line = line.replaceAll(">(\\d+:\\d+)<","=$1=");

         // replace all < > with [ ]. The < > are HTML tags, so we will use a different 
         // Strong's number deliniator.
         line = line.replaceAll("<","[");
         line = line.replaceAll(">","]");

         // Remove the (##), since these are not Strongs. They may have a leading and trailing blank,
         // if so only remove one of the blanks
         line = line.replaceAll( "( ?\\(\\d+\\)|\\(\\d+\\) ?)" ,"" );
         
         // remove the blank between contiguous Strongs numbers, so that
         // it doesnt look like text in later replace below. [123][3456]
         line = line.replaceAll( "\\] \\[" ,"][" );
         
         ///////////// ADDING HTML TAGS PER ROW ////////////////
         // Put Hebrew/Greek on next line(row).
         // Find this: . 81
         line = line.replaceFirst("(" + someText + ")(\\d+)", "$1" + CLOSE_ROW + NEXT_ROW + "$2");
         
         // Begin each line with opening tags.
         // Find this: 18  I have waited for 
         line = line.replaceFirst( "(\\d+)", OPENING_LINE_TABLE + "$0" + OPENING_TABLE);
         
         // Separate the words from the [##], (##) Strongs numbers that identify the words.
         // Notice that some of these replacements will find overlapping chunks of text
         //   to insert HTML before and after text.
         // Find this: I have waited for [
         line = line.replaceAll("(" + someText + ")\\[(\\d+)", "$1" + OPEN_UNDER + "[$2");
//                                line = line.replaceAll("(" + someText + ")\\(", "$1 OPEN_UNDER (");
         
         // Create an HTML table such that the words are on the same line with the numbers below. 
         // Find this: ] thy salvation 
         line = line.replaceAll("\\](" + someText + ")", "]" + CLOSE_UNDER + "$1");
//                                 line = line.replaceAll("\\)(" + someText + ")", ") CLOSE_UNDER, NEXT_WORD $1");
         
         // Group these [##] and (##) together somehow, currently we will put these numbers under the words
         // they identify in an HTML table.
         // Find this: ] (
         //    or any combination of these.
//                                 line = line.replaceAll("\\] \\(", "] STAY_UNDER (");
         line = line.replaceAll("\\]\\[(\\d+)", "]" +  STAY_UNDER + "[$1");
//                                 line = line.replaceAll("\\) \\(", ") STAY_UNDER (");
//                                 line = line.replaceAll("\\) \\[", ") STAY_UNDER [");
         
         // Put Hebrew/Greek on next line(row). This is unusual but does happen.
         // We normally expect a period or punctuation rather than ] between KJV and Heb/Grk.
         // Find this if it exists: ] 81
         line = line.replaceAll("\\]( ?\\d+)", "]" + CLOSE_ROW + NEXT_ROW + "$1");
//                                 line = line.replaceAll("\\)( ?\\d+)", ") CLOSE_ROW, NEXT_ROW $1");
         
         // Remove the square brackets from around Strongs numbers.
         // Remember that some of this stuff is order dependent.
         line = line.replaceAll("\\[(\\d+)\\]","$1");

         // Close each line with closing HTML
         line = line.replaceAll("$", CLOSE_LINE_TABLE);
         
         // substitute in the language name for bju.edu/bible/strongs/Hebrew/123.inc
         line = line.replaceAll("_LANGUAGE", language);
         
         
         return line;  
  }

   static public String addHTMLSimple( String line) {
   	 //System.out.println("Entering addHTML: " + line);
   	        
   	    final String OPENING_LINE_TABLE = "<TABLE width=900><TR><TD><TABLE><TR VALIGN=\"top\"><TD>";           
        final String OPENING_TABLE_SIMPLE = "</TD><TD><SPAN class=english>";
        final String CLOSE_LINE_TABLE = "</SPAN></TD></TR></TABLE></TR></TABLE>";

         // Example line:
         //  18  I have waited for <06960> (8765) thy salvation <03444>, O LORD <03068>. 81  ???????? ????? ????<br>

         //////////// REMOVING OR REPLACING SECTION. CLEAN UP CHARACTERS FOR HTML TAGS. ////////// 
         // clean up extra <00>
         line = line.replaceAll("<0+>","");
         // remove leading 0s in strongs for now, bju.edu/bible doesnt use them.  
         line = line.replaceAll("<0(\\d+)>","<$1>");

         // change >3:2< to =3:2=
         line = line.replaceAll(">(\\d+:\\d+)<","=$1=");

         // replace all < > with [ ]. The < > are HTML tags, so we will use a different 
         // Strong's number deliniator. 
         line = line.replaceAll("<","[");
         line = line.replaceAll(">","]");
         
         // Remove the (##), since these are not Strongs. They may have a leading and trailing blank,
         // if so only remove one of the blanks
         line = line.replaceAll( "( ?\\(\\d+\\)|\\(\\d+\\) ?)" ,"" );
         
         // remove the blank between contiguous Strongs numbers, so that
         // it doesnt look like text in later replace below. [123][3456]
         line = line.replaceAll( "\\] \\[" ,"][" );
         
         ///////////// ADDING HTML TAGS PER ROW ////////////////
         
         // Begin each line with opening tags.
         // Find this: 18  I have waited for 
         line = line.replaceFirst( "(\\d+)", OPENING_LINE_TABLE + "$0" + OPENING_TABLE_SIMPLE);
         

         // Close each line with closing HTML
         line = line.replaceAll("$", CLOSE_LINE_TABLE);
         
         // substitute in the language name for bju.edu/bible/strongs/Hebrew/123.inc
         line = line.replaceAll("_LANGUAGE", language);
         
         return line;  
  }

   static public String addHTMLOriginal( String line) {
   	 //System.out.println("Entering addHTML: " + line);
   	 
   	    final String OPENING_LINE_TABLE = "<TABLE width=900><TR class=hebrew VALIGN=\"top\"><TD width=40>";           
        final String OPENING_TABLE_SIMPLE = "</TD><TD><!-- COMMENT ";
        final String CLOSE_LINE_TABLE = "</TD></TR></TABLE>";
        final String END_COMMENT = "-->";

         // Example line:
         //  18  I have waited for <06960> (8765) thy salvation <03444>, O LORD <03068>. 81  ???????? ????? ????<br>

         //////////// REMOVING OR REPLACING SECTION. CLEAN UP CHARACTERS FOR HTML TAGS. ////////// 
         // clean up extra <00>
         line = line.replaceAll("<0+>","");
         // remove leading 0s in strongs for now, bju.edu/bible doesnt use them.  
         line = line.replaceAll("<0(\\d+)>","<$1>");
         
         // change >3:2< to =3:2=
         line = line.replaceAll(">(\\d+:\\d+)<","=$1=");

         // replace all < > with [ ]. The < > are HTML tags, so we will use a different 
         // Strong's number deliniator.
         line = line.replaceAll("<","[");
         line = line.replaceAll(">","]");

         // Remove the (##), since these are not Strongs. They may have a leading and trailing blank,
         // if so only remove one of the blanks
         line = line.replaceAll( "( ?\\(\\d+\\)|\\(\\d+\\) ?)" ,"" );
         
         // remove the blank between contiguous Strongs numbers, so that
         // it doesnt look like text in later replace below. [123][3456]
         line = line.replaceAll( "\\] \\[" ,"][" );
         
         // Keep Hebrew/Greek, comment out the rest.
         // Find this: . 81
         line = line.replaceFirst("(" + someText + ")(\\d+)", "$1" + "$2"+ END_COMMENT );
         
         // We normally expect a period or punctuation rather than ] between KJV and Heb/Grk.
         // Find this if it exists: ] 81
         line = line.replaceAll("\\]( ?\\d+)", "]" + "$1"+ END_COMMENT );

         ///////////// ADDING HTML TAGS PER ROW ////////////////
         
         // Begin each line with opening tags.
         // Find this: 18  I have waited for 
         line = line.replaceFirst( "(\\d+)", OPENING_LINE_TABLE + "$0" + OPENING_TABLE_SIMPLE);
         

         // Close each line with closing HTML
         line = line.replaceAll("$", CLOSE_LINE_TABLE);
         
         // substitute in the language name for bju.edu/bible/strongs/Hebrew/123.inc
         line = line.replaceAll("_LANGUAGE", language);
         
         return line;  
  }

  public void createOutputDirectoryIfNeeded(String outputDirectoryString){
      try {
         File directory = new File(outputDirectoryString);
         if (directory.exists()){
           return;
         } else {
            directory.mkdirs();    
         }
      }catch (SecurityException e) {
         System.out.println(e.toString());
      }        
      return; 
  }

  public void printLongestLine(){
		       
       System.out.println("Longest Line in this Book and Chapter: " + longName + " in characters: " + longLineLength);
  }

  public void createIndex(FileNameParts fileNameParts){
    try{
        OutputUTF16File OIndexStream = new OutputUTF16File();
         // Create the indexes one level up in the directory structure so that OT and NT books are in the same Index file.
        OIndexStream.open(fileNameParts.getCurrentIndexFileName());
     
        String line  = header + HTML_FILE_BEGIN;
        line = line.replaceAll("BOOKNAME", "Bible") ;
        line = line.replaceAll("CHAPTERNUMBER", "" + "All");
        
        line = line.replaceAll("RELATIVEPATHCURRENTFORMAT", "");
        line = line.replaceAll("RELATIVEPATHCURRENT", "");

        line = line.replaceAll("RELATIVEPATHONEFORMAT", fileNameParts.getRelativePathFormatOne());
        line = line.replaceAll("RELATIVEPATHONE", "./Index" + fileNameParts.getRelativePathFormatOne() + ".html");
        line = line.replaceAll("RELATIVEPATHTWOFORMAT", fileNameParts.getRelativePathFormatTwo());
        line = line.replaceAll("RELATIVEPATHTWO", "./Index" + fileNameParts.getRelativePathFormatTwo() + ".html");                         


        OIndexStream.write(line , 0, line.length());
 
        Vector allBookNames = fileNameParts.getFileNameChapterAll();
        Enumeration allEnum = allBookNames.elements();
        while(allEnum.hasMoreElements()){
            KeyValuePair nameChaptersNumbers = (KeyValuePair)allEnum.nextElement();
            StringBuffer bookLine = new StringBuffer("<TABLE><TR><TD>" + nameChaptersNumbers.getKey() + "</TD>\n");            
            
            Vector nameChapterVec = (Vector)nameChaptersNumbers.getValue();
            Enumeration nameChapterEnum = nameChapterVec.elements();
            
            while(nameChapterEnum.hasMoreElements()){
               KeyValuePair nameChapter = (KeyValuePair)nameChapterEnum.nextElement();               
               bookLine.append("<TD><a href=" + nameChapter.getKey() + ">" + ((Long)nameChapter.getValue()).toString() + "</a></TD>\n");
            }
            bookLine.append("</TR></TABLE>\n");
           String bLine = bookLine.toString();    
           OIndexStream.write(bLine , 0, bLine.length());
        }
        System.out.println("CLOSING INDEX");

       OIndexStream.write(HTML_FILE_END , 0, HTML_FILE_END.length());                  
       OIndexStream.closeOut("closing Index");
     
     }catch(Exception e){
        System.out.println(e.toString());
     }

  }

}
          

class InputUTF16File {
	private InputStreamReader rdr = null;
    private FileInputStream FIStream = null;
    private BufferedReader in = null;

    InputUTF16File(){
    }

    public BufferedReader open(String fullPathFileName) {
         try{
             // open file for reading, unicode bigendian.                   
             FIStream = new FileInputStream(fullPathFileName);    
             rdr = new InputStreamReader(FIStream, "utf-16be");                          
             in = new BufferedReader(rdr);
                                
         }catch (Exception e) {
  	         System.out.println(e.toString());
             e.printStackTrace(System.out);
            System.exit(0);
         } // catch

         return in;
    }

    public void close(){
      try {
           // Close the file
           FIStream.close();
           rdr.close();
     }catch (Exception e) {
  	     System.out.println(e.toString());
         e.printStackTrace(System.out);
         System.exit(0);
     } // catch

    }
}

class OutputUTF16File {
    private OutputStreamWriter outStream = null;
    private OutputStream OS = null;

    OutputUTF16File(){
    }

    public OutputStreamWriter open(String fullPathOutputFile){
        try {
           OS = new FileOutputStream(fullPathOutputFile);
           outStream = new OutputStreamWriter( OS, "utf-16be");
 
       }catch (Exception e) {
          System.out.println(e.toString());
          e.printStackTrace(System.out);
          System.exit(0);
       } //catch
       return outStream;
    }

    /**
      Assuming if null that we have closed, or not opened yet.
    */
    public boolean isOpen(){
        if(outStream != null ){
           return true;
        }
        return false;
    
    }
   
    public OutputStreamWriter getOutStream() {
        return outStream;
    }

    public void write(String lineOrData, int start, int end) throws IOException {
    
        if (isOpen()) {
            outStream.write(lineOrData , start, end);
        } else {
            System.out.println("write failed, outStream null or closed.");
        }   
    }

    public void closeOut(String infoMsg)throws IOException {
        try {

   	   // close if open for next chapter output file.
       if (outStream != null ) {
         System.out.println(infoMsg);
         outStream.flush();
         outStream.close();
         OS.flush();
         OS.close();
         outStream = null;                        
         OS = null;
      }
       }catch (Exception e) {
          System.out.println(e.toString());
          e.printStackTrace(System.out);
          System.exit(0);
       } //catch
    }
}

class FileNameParts {
    // We load all the file paths up on the first file,
    // This way we can cross index the indexes and chapters as we go.
   private String inputBookFileName = "";
   private String bookFileNameMinustxt = "";
   private String inputDirectoryString = "";
   private String outputDirectoryString = "";
   private long chapterNumber = 0;
   
   private String currentHTMLFormat = ""; // Full, Simple, Original
   private static HashMap filePaths = new HashMap();
   private Enumeration    BibleEnum = null;
   
   // This is for building the index, or anything that needs all of the books and last
   // chapter, after all the books from the NT and OT are converted. (and if you add apocrapha)
   private KeyValuePair FileNameLastChapter= null;
   private Vector  FileNameChapterAll = new Vector();
   private Vector  FileNameChapter = new Vector();
   
   // This vector contains 2 element vectors of the relative path and the format
   // Example: "../KJVNewTestamentAndGreekWHSimpleHTML/", "Simple"
   // So the current format is not in this vector, each format gets a new FileNameParts
   // which reinitializes this.
   Vector relativeOutPathsNT = new Vector();
   Vector relativeOutPathsOT = new Vector();
   
            
   FileNameParts(String currentHTMLFormat)throws IOException {
    
     if ( ! (currentHTMLFormat.equals("Full")     || 
             currentHTMLFormat.equals("Simple")   ||
             currentHTMLFormat.equals("Original")   ) ) {
        throw new IOException("OOPS, need to enter Full, Simple, or Original in call to this method. You entered: " + currentHTMLFormat);

   }
  
     this.currentHTMLFormat = currentHTMLFormat;     
     
     if ( filePaths.isEmpty()){
     
        filePaths.put("Full", directoryPathInfoFull());
        filePaths.put("Simple", directoryPathInfoSimple());    
        filePaths.put("Original", directoryPathInfoOriginal());
     }
  
     // assumption: inputDirectory is first element, outputDirectory is last element.
     Vector currentBible = (Vector)filePaths.get(currentHTMLFormat);
     // Each Bible has a OT and NT Vector, we start with the first one.
     Vector currentPaths = (Vector)currentBible.firstElement();
     this.inputDirectoryString = (String)currentPaths.firstElement();
     this.outputDirectoryString = (String)currentPaths.lastElement();
  
     configureRelativePaths(currentHTMLFormat);         
     
     BibleEnum = getPaths(currentHTMLFormat).elements();
       
   }
  
   /**
    * Each element contains a Vector with the input and output directories of the OT or NT.
   */
   public boolean hasMoreElements(){
      return BibleEnum.hasMoreElements();   
   }

   public Vector nextElement(){
       Vector nextBibleSection = (Vector)BibleEnum.nextElement(); 
       this.inputDirectoryString = (String)nextBibleSection.firstElement();
       this.outputDirectoryString = (String)nextBibleSection.lastElement();
       return nextBibleSection;
   }

   public Vector getPaths(String currentHTMLFormat){
       return (Vector)filePaths.get(currentHTMLFormat);
   }

   public static Vector directoryPathInfoFull() {
          // input, output pair of directory paths for OT.          
          Vector booklistOT = new Vector();                   	
          booklistOT.add("C:\\BibleStrongsUnicode\\KJVOldTestamentAndHebrew");
          booklistOT.add("C:\\BibleStrongsUnicode\\KJVOldTestamentAndHebrewHTML");
          
          // input, output pair of directory paths for NT.
          Vector booklistNT = new Vector();                   
          booklistNT.add("C:\\BibleStrongsUnicode\\KJVNewTestamentAndGreekWH");
          booklistNT.add("C:\\BibleStrongsUnicode\\KJVNewTestamentAndGreekWHHTML");
          
          Vector allTheDirectoryPaths = new Vector();
          allTheDirectoryPaths.add(booklistOT);
          allTheDirectoryPaths.add(booklistNT);

          // Use each directory name to return a list of book names from that directory.
          // This is a list of directories containing books of the Bible, usually one
          // for Old and one for New Testament.
          return allTheDirectoryPaths;
   }    

   public static Vector directoryPathInfoSimple() {
		
          // input, output pair of directory paths for OT.          
          Vector booklistOT = new Vector();                   	
          booklistOT.add("C:\\BibleStrongsUnicode\\KJVOldTestamentAndHebrew");
          booklistOT.add("C:\\BibleStrongsUnicode\\KJVOldTestamentAndHebrewSimpleHTML");
          
          // input, output pair of directory paths for NT.
          Vector booklistNT = new Vector();                   
          booklistNT.add("C:\\BibleStrongsUnicode\\KJVNewTestamentAndGreekWH");
          booklistNT.add("C:\\BibleStrongsUnicode\\KJVNewTestamentAndGreekWHSimpleHTML");
          
          Vector allTheDirectoryPaths = new Vector();
          allTheDirectoryPaths.add(booklistOT);
          allTheDirectoryPaths.add(booklistNT);

          // Use each directory name to return a list of book names from that directory.
          // This is a list of directories containing books of the Bible, usually one
          // for Old and one for New Testament.
          return allTheDirectoryPaths;
   }

   public static Vector directoryPathInfoOriginal() {
		
          // input, output pair of directory paths for OT.          
          Vector booklistOT = new Vector();                   	
          booklistOT.add("C:\\BibleStrongsUnicode\\KJVOldTestamentAndHebrew");
          booklistOT.add("C:\\BibleStrongsUnicode\\KJVOldTestamentAndHebrewOriginalLanguageHTML");
          
          // input, output pair of directory paths for NT.
          Vector booklistNT = new Vector();                   
          booklistNT.add("C:\\BibleStrongsUnicode\\KJVNewTestamentAndGreekWH");
          booklistNT.add("C:\\BibleStrongsUnicode\\KJVNewTestamentAndGreekWHOriginalLanguageHTML");
          
          Vector allTheDirectoryPaths = new Vector();
          allTheDirectoryPaths.add(booklistOT);
          allTheDirectoryPaths.add(booklistNT);

          // Use each directory name to return a list of book names from that directory.
          // This is a list of directories containing books of the Bible, usually one
          // for Old and one for New Testament.
          return allTheDirectoryPaths;
   }    

   private void configureRelativePaths(String currentHTMLFormat) {
      try {
      
      Iterator pathsIter = filePaths.keySet().iterator();
      while (pathsIter.hasNext() ){
          String HTMLFormat = (String)pathsIter.next();
        System.out.println("NEXT RELPATH FORMAT: " + HTMLFormat);
          
          // Add the paths that are different from what you are processing.
          // These paths are used as links from the current format pages to
          // the other formats. HTMLFormat = Full, Simple, Original.
          if ( !currentHTMLFormat.equals(HTMLFormat) ){
        System.out.println("currentHTMLFormat: " + currentHTMLFormat);
              Enumeration enum = ((Vector)filePaths.get(HTMLFormat)).elements();
              while (enum.hasMoreElements()){
        System.out.println("NEXT RELPATH FORMAT: " + HTMLFormat);
                // This allows us to loop over the directories of OT and NT books.
                // In theory there could be several versions of the Bible, we use KJV.
                Vector inputOutputDirectoryStrings = (Vector)enum.nextElement();
                //String inputDirectoryString = (String)inputOutputDirectoryStrings.firstElement();
                String outputDirectoryString = (String)inputOutputDirectoryStrings.lastElement();
                String[] pathPieces = outputDirectoryString.split("\\\\");
                Vector HTMLInfo = new Vector();
                HTMLInfo.add("../" + pathPieces[pathPieces.length-1] + "/");
                HTMLInfo.add(HTMLFormat);
                if ( outputDirectoryString.indexOf("Hebrew") > 0) relativeOutPathsOT.add(HTMLInfo);
                if ( outputDirectoryString.indexOf("Greek") > 0)  relativeOutPathsNT.add(HTMLInfo);               
              }                       
          }
      }
    
      }catch (Exception e){
        System.out.println(e.toString());
      }
   }
  
   public String getCurrentHTMLFormat(){
      return currentHTMLFormat;
   }
  
   public String getRelativePathOne(){
      Vector tVec = null;
      if ( outputDirectoryString.indexOf("Hebrew") > 0) tVec = (Vector)relativeOutPathsOT.firstElement();
      if ( outputDirectoryString.indexOf("Greek") > 0)  tVec = (Vector)relativeOutPathsNT.firstElement();
                
      return (String)tVec.firstElement() + getOutputFile();
  
   }

   public String getRelativePathTwo(){
      Vector tVec = null;
      if ( outputDirectoryString.indexOf("Hebrew") > 0) tVec = (Vector)relativeOutPathsOT.lastElement();
      if ( outputDirectoryString.indexOf("Greek") > 0)  tVec = (Vector)relativeOutPathsNT.lastElement();
                
      return (String)tVec.firstElement() + getOutputFile();
  
   }

   public String getRelativePathFormatOne(){
      Vector tVec = null;
      if ( outputDirectoryString.indexOf("Hebrew") > 0) tVec = (Vector)relativeOutPathsOT.firstElement();
      if ( outputDirectoryString.indexOf("Greek") > 0)  tVec = (Vector)relativeOutPathsNT.firstElement();
                
      return (String)tVec.lastElement();
  
   }
 
   public String getRelativePathFormatTwo(){
      Vector tVec = null;
      if ( outputDirectoryString.indexOf("Hebrew") > 0) tVec = (Vector)relativeOutPathsOT.lastElement();
      if ( outputDirectoryString.indexOf("Greek") > 0)  tVec = (Vector)relativeOutPathsNT.lastElement();
                
      return (String)tVec.lastElement();
  
   }

  public String getInputDirectoryString(){
     return this.inputDirectoryString;
  }

  public String getOutputDirectoryString(){
     return this.outputDirectoryString;
  }

   public String getFullInputFile(){
      return inputDirectoryString + "\\"+ inputBookFileName;  
  }
   
   public String getFullOutputFile() {
     return outputDirectoryString + "\\" + getOutputFile();  
   }
 
   public String getOutputFile() {
    
     // Format each chapter number to have leading zeros. This is 
     // so that the chapters will be numerically listed, even though
     // they are alphabetically sorted.

     System.out.println("new chapter: " + getChapter());                     
     DecimalFormat leadingZeros = new DecimalFormat("000");
     String zeroPaddedCount = leadingZeros.format(getChapter());
                   
     System.out.println("output chapter: " + bookFileNameMinustxt);

     return bookFileNameMinustxt + zeroPaddedCount + ".html";  
   }
  
  public String getBookFileNameMinustxt(){
     return bookFileNameMinustxt;
  }

  public String getPrinterBookName(){
     return bookFileNameMinustxt.replaceFirst("[a-z]+", "");
   }
  
   public void incrementChapter(){
       chapterNumber++;
       FileNameChapter.add(  new KeyValuePair( getOutputDirectoryString() + "/" + getOutputFile(), new Long(getChapter()) )  );

   }
  
   public void resetChapterCount(){
      chapterNumber = 0; 
    }
  
   public long getChapter(){
      return this.chapterNumber;
   } 
   
   public void setCurrentFileName( String bookFileName ) {
      System.out.println("Input File Name: " + bookFileName);
      this.inputBookFileName = bookFileName;
      FileNameChapter = new Vector();
      
      // File names input are expected to be txt files, drop the .txt here.
      int periodIndex = inputBookFileName.indexOf(".txt");
      bookFileNameMinustxt = inputBookFileName.substring(0,periodIndex);
   }

   public void addBookAndLastChapter(){
      
      FileNameChapterAll.add(new KeyValuePair(getPrinterBookName(), FileNameChapter));   
   }

   public Vector getFileNameChapterAll(){
      return FileNameChapterAll;
   }
  
  public String getCurrentIndexFileName() {
    return getOutputDirectoryString() + "/../Index" + currentHTMLFormat + ".html" ;
 
  }

  public String getRelativeCurrentIndexFileName() {
    return "../Index" + currentHTMLFormat + ".html" ;
 
  }
}

class KeyValuePair {
    
   private String key = "";
   private Object value = null;

   public KeyValuePair ( String key, Object value){
      this.key = key;
      this.value = value;   
   }
  
   public String getKey(){
      return this.key;
   }

   public Object getValue(){
      return this.value;
  }
}                                  
                                  

